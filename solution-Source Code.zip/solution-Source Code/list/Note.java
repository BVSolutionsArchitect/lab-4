package list;

public class Note {
    public String UserId;
    public String NoteId;
    public String Note;
}
